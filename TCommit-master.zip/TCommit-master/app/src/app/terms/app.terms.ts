import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-terms',
  templateUrl: './app.terms.html',
  styleUrls: ['./../app.component.css']
})
export class TermsComponent implements OnInit {
    ngOnInit() {}
}