import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-aboutus',
  templateUrl: './app.aboutUs.html',
  styleUrls: ['./../app.component.css']
})
export class AboutUsComponent implements OnInit {
    ngOnInit() {}
}