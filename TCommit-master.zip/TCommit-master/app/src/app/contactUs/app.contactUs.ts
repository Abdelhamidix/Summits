import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-contactus',
  templateUrl: './app.contactUs.html',
  styleUrls: ['./../app.component.css']
})
export class ContactUsComponent implements OnInit {
    ngOnInit() {}
}