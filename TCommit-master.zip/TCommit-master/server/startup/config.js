module.exports={
    "secret":"thisisdemoexpressapitokenbasedathentication",
    "database":""
}
